@extends('layouts.template')

@section('content')
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        @if ($cart && count($cart->items) > 0)
        <div class="col-md-12">
            <div class="h-100 bg-secondary rounded p-4 d-flex flex-column align-items-center justify-content-center">
                <h4>Total: R$ {{ number_format($cart->getTotalPrice(), 2, ',', '.') }}</h4>
                <a href="{{ route('cart.generateQRCode') }}" class="btn btn-primary">Gerar QR CODE PIX</a>
            </div>
        </div>
        @endif
        <hr>
        <div class="container">
            <div class="col-md-12">
                <div class="h-100 bg-secondary rounded flex-column align-items-center justify-content-center p-4 ">
                    @if ($cart && count($cart->items) > 0)
                    <div class="row">
                        @foreach ($cart->items as $item)
                            <div class="col-md-4">
                                <div class="item-card">
                                    <div class="card-header">
                                        <p>{{ $item['name'] }}</p>
                                    </div>
                                    <div class="card-body">
                                        <p><strong>Quantidade:</strong> {{ $item['quantity'] }}</p>
                                        <p><strong>Valor Unitário:</strong> R$ {{ number_format($item['price'], 2, ',', '.') }}</p>
                                        <p><strong>Valor Total:</strong> R$ {{ number_format($item['quantity'] * $item['price'], 2, ',', '.') }}</p>
                                    </div>
                                    <div class="card-footer">
                                        <form action="{{ route('cart.update', $item['id']) }}" method="POST" class="d-flex align-items-right justify-content-right">
                                            @csrf
                                            @method('PUT')
                                            <input type="hidden" name="quantity" value="0" class="form-control" style="width: 20px;">
                                            <button type="submit" class="btn btn-sm btn-primary ms-2 align-items-right justify-content-right">
                                                <i class="fa fa-trash"></i> 
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
        @else
            <div class="col-md-12">
                <div class="h-100 bg-secondary rounded p-4 d-flex flex-column align-items-center justify-content-center">
                    <p>Carrinho vazio.</p>
                </div>
            </div>
        @endif
    </div>
</div>
@endsection
