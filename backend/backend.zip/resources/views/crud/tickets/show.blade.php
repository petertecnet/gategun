@extends('layouts.template')

@section('content')
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-md-12">
                <div class="h-100 bg-secondary rounded p-4 d-flex flex-column align-items-center justify-content-center">
                    <h2 class="text-center mt-2">{{ $event_name }}</h2>
                </div>
            </div>
            <hr>

            <div class="container">
                <div class="row g-4"> 
                    <!-- Adicione esta div para envolver o loop de ingressos -->
                    @if($tickets && count($tickets) > 0)
                        @foreach ($tickets as $ticket)
                            <div class="col-md" >
                                <div class="h-200 bg-gategun rounded p-5" >
                                    <div class="d-flex w-100 justify-content-center" >
                                        <h6 class="mb-0 text-gategunwhite">{{ $ticket->name }}</h6>
                                    </div>
                                    <div class="d-flex align-items-center border-bottom py-3" >
                                        <div class="w-100 ms-3">
                                            <div class="d-flex w-100 justify-content-center">
                                                <h6 class="text-gategunwhite">{{ 'R$ ' . number_format($ticket->price, 2, ',', '.') }}</h6>
                                            </div>

                                             <div class="d-flex align-items-center">
                                                <div class="d-flex w-100 justify-content-center">
                                                <button class="btn btn-sm btn-primary me-2" onclick="decreaseQuantity({{ $ticket->id }})">-</button>
                                                <input type="number" id="quantityInput-{{$ticket->id}}" data-price="{{$ticket->price}}" value="0" class="input-sm-gategun">   <button class="btn btn-sm btn-primary ms-2" onclick="increaseQuantity({{ $ticket->id }})">+</button>
                                            </div>      </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <div class="col-md-12">
                            <p>Nenhum ingresso cadastrado para este produtor.</p>
                        </div>
                    @endif
                </div> <!-- Feche a div envolvendo o loop de ingressos -->
            </div>
        </div>
    </div>

    <a href="#" class="btn btn-primary btn-fixed-gategun" id="finalizarCompraBtn" onclick="finalizePurchase()">Finalizar compra R$ 0,00</a>

    <script>
        
        function increaseQuantity(ticketId) {
            const quantityInput = document.getElementById(`quantityInput-${ticketId}`);
            const quantity = parseInt(quantityInput.value);
            quantityInput.value = quantity + 1;
            updateTotalValue();
        }

        function decreaseQuantity(ticketId) {
            const quantityInput = document.getElementById(`quantityInput-${ticketId}`);
            const quantity = parseInt(quantityInput.value);
            if (quantity > 0) {
                quantityInput.value = quantity - 1;
                updateTotalValue();
            }
        }
        function updateTotalValue() {
        let totalValue = 0;
        const ticketInputs = document.querySelectorAll('[id^="quantityInput-"]');
        
        ticketInputs.forEach((input) => {
            const quantity = parseInt(input.value);
            const ticketPrice = parseFloat(input.dataset.price);
            
            totalValue += ticketPrice * quantity;
        });

        const formattedTotalValue = totalValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        document.getElementById('finalizarCompraBtn').innerText = `Finalizar compra ${formattedTotalValue}`;
    }


        function finalizePurchase() {
            const totalValue = document.getElementById('finalizarCompraBtn').innerText;
            alert("Compra finalizada! Valor total: " + totalValue);
        }
    </script>
@endsection
