<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;

    protected $fillable = [
        'event_id',
        'name',
        'type',
        'price',
        'ticket_type',
        'quantity',
        'description',
        // Adicione outros campos relevantes aqui, se houver.
    ];

    // Relação com o model Event (um ingresso pertence a um evento)
    public function event()
    {
        return $this->belongsTo(Event::class);
    }

    // Função para pegar o nome do evento
    public function getEventName()
    {
        // Verifica se o ingresso tem um evento associado
        if ($this->event) {
            // Retorna o nome do evento
            return $this->event->name;
        } else {
            return 'Evento não encontrado';
        }
    }
    public function eventId()
    {
        // Verifica se o ingresso tem um evento associado
        if ($this->event) {
            // Retorna o nome do evento
            return $this->event->id;
        } else {
            return 'Id do evento não encontrado';
        }
    }

    // Relação com o model Production (um ingresso pertence a uma produção)
    public function production()
    {
        return $this->belongsTo(Production::class);
    }
}
