<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    use HasFactory;

    protected $table = 'items';

    protected $fillable = [
        'name',
        'quantity',
        'eventid',
        'type',
        'description',
        'cart_id',
        'is_used',
        'user_id',
    ];

    // Relacionamento com o carrinho
    public function cart()
    {
        return $this->belongsTo(Cart::class, 'cart_id');
    }

    // Relacionamento com o evento
    public function event()
    {
        return $this->belongsTo(Event::class, 'eventid');
    }

    // Outros métodos ou relacionamentos, se houver
}
