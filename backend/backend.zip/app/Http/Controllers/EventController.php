<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image; 
use Carbon\Carbon;
use Illuminate\Support\Facades\File;


class EventController extends Controller
{
    public function index()
    {
        $events = Event::all();
        return view('events.index', compact('events'));
    }

    public function create()
    {
        return view('events.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|max:255',
            'description' => 'required',
            'date' => 'required|date',
            'time' => 'required',
            'location' => 'required',
            'price' => 'required|numeric|min:0',
            'image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $directoryPath = public_path('productions');

        if (!File::exists($directoryPath)) {
            File::makeDirectory($directoryPath, 0755, true);
        }

        if ($request->hasFile('image')) {
            $imgprod = $request->file('image');

            // Redimensionar a imagem para 900x600
            $image = Image::make($imgprod)->fit(900, 600);
            $image->save($directoryPath . '/' . $imgprod->getClientOriginalName());

            $imagePath = 'productions/' . $imgprod->getClientOriginalName();
        }

        // Criação do evento no banco de dados
        $event = Event::create([
            'name' => $request->input('name'),
            'description' => $request->input('description'),
            'date' => $request->input('date'),
            'time' => $request->input('time'),
            'location' => $request->input('location'),
            'price' => $request->input('price'),
            'image' => $imagePath,
            'production_id'=> $request->input('production_id'),
            'production_name'=> $request->input('production_name'),
        ]);

        // Redirecionamento para a página de exibição do evento recém-criado
        return redirect()->route('events.show', $event->id);
    }
    public function show($id)
    {
        $event = Event::findOrFail($id);
        $tickets = Ticket::where('event_id', $event->id)->get();
        $event->date = Carbon::parse($event->date);
        return view('crud.events.show', compact('event', 'tickets'));
    }
    

    public function edit(Event $event)
    {
        
        $tickets = Ticket::where('event_id', $event->id)->get();
        return view('crud.events.update', compact('event', 'tickets'));
    }

    public function update(Request $request, Event $event)
    {
        $request->validate([
            'name' => 'required|max:255',
            'description' => 'required',
            'date' => 'required|date',
            'time' => 'required',
            'location' => 'required',
            'price' => 'required|numeric|min:0',
            'image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $directoryPath = public_path('productions');

        if (!File::exists($directoryPath)) {
            File::makeDirectory($directoryPath, 0755, true);
        }

        if ($request->hasFile('image')) {
            $imgprod = $request->file('image');

            // Redimensionar a imagem para 900x600
            $image = Image::make($imgprod)->fit(900, 600);
            $image->save($directoryPath . '/' . $imgprod->getClientOriginalName());

            $imagePath = 'productions/' . $imgprod->getClientOriginalName();
        } else {
            // Caso a imagem não tenha sido enviada no request, manter a imagem atual do evento
            $imagePath = $event->image;
        }

        // Atualização do evento no banco de dados
        $event->update([
            'name' => $request->input('name'),
            'description' => $request->input('description'),
            'date' => $request->input('date'),
            'time' => $request->input('time'),
            'location' => $request->input('location'),
            'price' => $request->input('price'),
            'image' => $imagePath,
        ]);

        // Redirecionamento para a página de exibição do evento atualizado
        return redirect()->route('events.show', $event->id)->with('success', 'Evento atualizado com sucesso!');
    }
    public function destroy(Event $event)
    {
        // Armazenar o ID do produtor antes de excluir o evento
        $producerId = $event->production_id;
    
        $event->delete();
    
        // Redirecionar para a página de detalhamento da produção
        return redirect()->route('productions.show', $producerId)->with('success', 'Evento excluído com sucesso!');
    }
}
