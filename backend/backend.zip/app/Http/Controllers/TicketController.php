<?php



namespace App\Http\Controllers;
use App\Models\Ticket;
use Intervention\Image\Facades\Image; 
use BaconQrCode\Renderer\Image\Png;
use BaconQrCode\Renderer\Image\RendererInterface;
use BaconQrCode\Renderer\Image\Svg;
use BaconQrCode\Renderer\RendererStyle;
use BaconQrCode\Writer;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    // Mostrar a lista de tickets
    public function index()
    {
        $tickets = Ticket::all();
        return view('crud.tickets.index', compact('tickets'));
    }

    // Mostrar o formulário de criação de ticket
    public function create()
    {
        return view('tickets.create');
    }

    // Armazenar um novo ticket no banco de dados
    public function store(Request $request)
    {
        $data = $request->validate([
            'event_id' => 'required|exists:events,id',
            'name' => 'required|string|max:255',
            'ticket_type' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'quantity' => 'required|numeric|min:0',
            // Outros campos do ticket
        ]);


        $ticket = Ticket::create($data);
        
        return redirect()->route('events.show', $ticket->event_id);  }

    // Mostrar os detalhes de um ticket específico
    public function show($id)
    {
       
    $tickets = Ticket::where('event_id', $id)->get();
    $ticket =  Ticket::where('event_id', $id)->first();
    $event_name = $ticket->event_name;
        return view('crud.tickets.show', compact('tickets', 'event_name'));
    }

    // Mostrar o formulário de edição de ticket
    public function edit($id)
    {
        $ticket = Ticket::findOrFail($id);
        return view('tickets.edit', compact('ticket'));
    }

    // Atualizar os dados de um ticket no banco de dados
    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            // Outros campos do ticket
        ]);

        $ticket = Ticket::findOrFail($id);
        $ticket->update($data);

        return redirect()->route('tickets.index')->with('success', 'Ticket atualizado com sucesso!');
    }

    // Excluir um ticket do banco de dados
    public function destroy($id)
    {
        $ticket = Ticket::findOrFail($id);
        $ticket->delete();

        return redirect()->route('tickets.index')->with('success', 'Ticket excluído com sucesso!');
    }

    public function payment()
    {
        $client = new \GuzzleHttp\Client();
        
        $response = $client->request('POST', 'https://api.pagar.me/core/v5/orders', [
          'body' => '{"items":[{"amount":1,"description":"Testes","quantity":1,"code":"21"}],"payments":[{"Pix":{"expires_in":32},"payment_method":"pix","amount":100}]}',
          'headers' => [
            'accept' => 'application/json',
            'authorization' => 'Basic c2tfcnBScUcwNkgySG9MQk1ZeDo=',
            'content-type' => 'application/json',
          ],
        ]);
        
        return $response;
    }

    
}
