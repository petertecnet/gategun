<?php



namespace App\Http\Controllers;
use App\Models\Ticket;
use Intervention\Image\Facades\Image; 
use BaconQrCode\Renderer\Image\Png;
use BaconQrCode\Renderer\Image\RendererInterface;
use BaconQrCode\Renderer\Image\Svg;
use BaconQrCode\Renderer\RendererStyle;
use BaconQrCode\Writer;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use App\Models\Cart;

class TicketController extends Controller
{
    // Mostrar a lista de tickets
    public function index()
    {
        // Obtém o usuário autenticado
        $user = auth()->user();
    
        // Obtém todos os carrinhos pagos do usuário
        $carts = Cart::where('user_id', $user->id)
            ->where('is_paid', 1)
            ->get();
    
        // Inicializa um array para armazenar os ingressos e suas quantidades
        $ticketQuantities = [];
    
        // Itera pelos carrinhos e extrai os ingressos do campo items
        foreach ($carts as $cart) {
            $items = $cart->items;
    
            // Itera pelos itens e verifica se o campo "type" é igual a "Ingresso"
            foreach ($items as $item) {
                if ($item['type'] === 'Ingresso') {
                    // Verifica se já existe um ticket para o mesmo ID
                    if (isset($ticketQuantities[$item['id']])) {
                        // Se existir, soma a quantidade atual à quantidade existente
                        $ticketQuantities[$item['id']]['quantity'] += $item['quantity'];
                    } else {
                        // Se não existir, cria um novo ticket com o ID, nome do ingresso e a quantidade atual
                        $ticketQuantities[$item['id']] = [
                            'id' => $item['id'],
                            'name' => $item['name'], // Nome do ingresso
                            'quantity' => $item['quantity'],// Nome do ingresso
                            'eventid' => $item['eventId'],
                        ];
                    }
                }
            }
        }
    
        // Agora temos o array $ticketQuantities com os IDs dos ingressos, seus nomes e suas quantidades somadas
    
        // Inicializa um array para armazenar os tickets finais
        $tickets = [];
    
        // Itera pelo array de quantidades para criar os tickets
        foreach ($ticketQuantities as $ticket) {
            // Verifica se a quantidade é maior que zero
            if ($ticket['quantity'] > 0) {
                // Adiciona o ticket ao array de tickets
                $tickets[] = $ticket;
            }
        }
    
        // Agora, você tem o array $tickets com os ingressos individuais, seus nomes e suas quantidades somadas corretamente
    
        return view('crud.tickets.index', compact('tickets'));
    }
    

    // Mostrar o formulário de criação de ticket
    public function create()
    {
        return view('tickets.create');
    }

    // Armazenar um novo ticket no banco de dados
    public function store(Request $request)
    {
        $data = $request->validate([
            'event_id' => 'required|exists:events,id',
            'name' => 'required|string|max:255',
            'ticket_type' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'quantity' => 'required|numeric|min:0',
            // Outros campos do ticket
        ]);


        $ticket = Ticket::create($data);
        
        return redirect()->route('events.show', $ticket->event_id);  }

    // Mostrar os detalhes de um ticket específico
    public function show($id)
    {
       
    $tickets = Ticket::where('event_id', $id)->get();
    $ticket =  Ticket::where('event_id', $id)->first();
        return view('crud.tickets.show', compact('tickets'));
    }

    // Mostrar o formulário de edição de ticket
    public function edit($id)
    {
        $ticket = Ticket::findOrFail($id);
        return view('tickets.edit', compact('ticket'));
    }

    // Atualizar os dados de um ticket no banco de dados
    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            // Outros campos do ticket
        ]);

        $ticket = Ticket::findOrFail($id);
        $ticket->update($data);

        return redirect()->route('tickets.index')->with('success', 'Ticket atualizado com sucesso!');
    }

    // Excluir um ticket do banco de dados
    public function destroy($id)
    {
        $ticket = Ticket::findOrFail($id);
        $ticket->delete();

        return redirect()->route('tickets.index')->with('success', 'Ticket excluído com sucesso!');
    }

  
  
public function payment(Request $request)
{
    $totalValue = $request->input('totalvalue');
    $totalValue =  $totalValue * 1; 

    $user = Auth::user();
    $ticketsData = $request->input('tickets');

    // Verifique se existem ingressos selecionados
    if (!$ticketsData) {
        return redirect()->back()->with('error', 'Nenhum ingresso selecionado.');
    }
    $ticketsArray = json_decode($ticketsData, true);
    // Inicialize variáveis para o valor total e os itens do pedido
    $totalValue = 0;
    $items = [];
dd($ticketsArray);
    // Calcule o valor total e crie os itens do pedido com base nos ingressos selecionados
    foreach ($ticketsArray  as $ticket) {
        $name = $ticket['name'];
        $quantity = $ticket['quantity'];
        $price = $ticket['price'];
        $itemTotal = $quantity * $price;

        $totalValue += $itemTotal;

        // Crie um array para representar cada item do pedido
        $items[] = [
            'name' => $name,
            'quantity' => $quantity,
            'price' => $price,
            'item_total' => $itemTotal,
        ];
    }

    $data = [
        'items' => $items,
        'customer' => [
            'name' => $user->name,
            'email' => $user->email,
            'type' => 'individual',
            'document' => '02292465167',
            'phones' => [
                'home_phone' => [
                    'country_code' => '55',
                    'number' => '22180513',
                    'area_code' => '21',
                ]
            ]
        ],
        'payments' => [
            [
                'payment_method' => 'pix',
                'pix' => [
                    'expires_in' => '600',
                    'additional_information' => [
                        [
                            'name' => 'Quantidade',
                            'value' => '1',
                        ]
                    ]
                ]
            ]
        ]
    ];

    try {
        $client = new \GuzzleHttp\Client();

        $response = $client->request('POST', 'https://api.pagar.me/core/v5/orders', [
            'json' => $data,
            'headers' => [
                'Authorization' => 'Basic c2tfcnBScUcwNkgySG9MQk1ZeDo=', // Substitua pela sua chave de autorização do Pagar.me
                'Accept' => 'application/json',
            ],
        ]);

        $responseData = json_decode($response->getBody()->getContents(), true);
        $qrCodeUrl = $responseData['charges'][0]['last_transaction']['qr_code_url'];
        $qrCode = $responseData['charges'][0]['last_transaction']['qr_code'];
        $idorder = $responseData['id'];

        // Retorna a view com o QR code
        return view('crud.tickets.qrcode', compact('qrCodeUrl', 'qrCode', 'idorder'));
    } catch (\Exception $e) {
        // Tratamento de exceção caso ocorra um erro na requisição
        return view('erro');
    }
}

public function checkPaymentStatus(Request $request)
{
    $orderId = $request->route('idorder');

    $client = new \GuzzleHttp\Client();

    try {
        $response = $client->request('GET', "https://api.pagar.me/core/v5/orders/{$orderId}", [
            'headers' => [
                'accept' => 'application/json',
                'authorization' => 'Basic c2tfcnBScUcwNkgySG9MQk1ZeDo=',
            ],
        ]);

        $responseData = json_decode($response->getBody()->getContents(), true);
        $status = $responseData['status'];

        // Obtém o carrinho do usuário autenticado
        $user = Auth::user();
        $cart = Cart::where('user_id', $user->id)
            ->where('is_paid', 0)
            ->first();

        if ($status === 'paid') {
            // Define o carrinho como pago
            $cart->is_paid = 1;
            $cart->save();

            // Itera pelos itens do carrinho e salva-os na tabela "items"
            $cartItems = json_decode($cart->items, true);
            foreach ($cartItems as $item) {
                if ($item['type'] === 'Ingresso') {
                    // Cria múltiplas instâncias de Item, uma para cada ingresso comprado
                    for ($i = 0; $i < $item['quantity']; $i++) {
                        $newItem = new Item([
                            'name' => $item['name'],
                            'quantity' => 1, // Cada ingresso é registrado individualmente com quantidade 1
                            'eventid' => $item['eventid'],
                            'type' => $item['type'],
                            'description' => $item['description'],
                            'cart_id' => $cart->id,
                            'is_used' => false, // Por padrão, o item não foi utilizado
                            'user_id' => $user->id,
                        ]);

                        // Salva o novo item na tabela "items"
                        $newItem->save();
                    }
                }
            }
        }

        // Retornar apenas o campo "status"
        return response()->json(['status' => $status]);
    } catch (\GuzzleHttp\Exception\RequestException $e) {
        // Tratamento de exceção caso ocorra um erro na requisição
        return false;
    }
}

    
}