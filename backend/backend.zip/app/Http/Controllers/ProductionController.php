<?php

namespace App\Http\Controllers;

use App\Models\Production;
use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\File;

class ProductionController extends Controller
{
    public function index()
    {
        $productions = Production::all();
        return view('crud.productions.index', compact('productions'));
    }

    public function create()
    {
        return view('productions.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'location' => 'required|string|max:255',
        ]);

        $user = Auth::user();$imagePath = $request->image;
        $directoryPath = public_path('productions');

        if (!File::exists($directoryPath)) {
            File::makeDirectory($directoryPath, 0755, true);
        }

        if ($request->hasFile('image')) {
            $imgprod = $request->file('image');

            // Check if there's a file with the same name as the uploaded file
            if (File::exists($directoryPath . '/' . $imgprod->getClientOriginalName())) {
                // Generate a new unique file name by adding a number to the end of the original file name
                $count = 1;
                $newFileName = pathinfo($imgprod->getClientOriginalName(), PATHINFO_FILENAME) . '_' . $count . '.' . $imgprod->getClientOriginalExtension();

                while (File::exists($directoryPath . '/' . $newFileName)) {
                    $count++;
                    $newFileName = pathinfo($imgprod->getClientOriginalName(), PATHINFO_FILENAME) . '_' . $count . '.' . $imgprod->getClientOriginalExtension();
                }

                // Rename the existing file with the new unique name
                File::move($directoryPath . '/' . $imgprod->getClientOriginalName(), $directoryPath . '/' . $newFileName);

                $imagePath = 'productions/' . $newFileName;
            } else {
                // If the file does not exist, simply move the uploaded file to the logos directory
                $imgprod->move($directoryPath, $imgprod->getClientOriginalName());
                $imagePath = 'productions/' . $imgprod->getClientOriginalName();
            }
        }

        $production = new Production([
            'name' => $request->name,
            'image' => $imagePath,
            'location' => $request->location,
            'user_id' => $user->id,
            'user_name' => $user->name,
        ]);

        $production->save();
        return redirect()->route('productions.index')->with('status', 'Produção cadastrada com sucesso!');
    }

    public function show(Production $production)
    {
        // Obter os eventos associados à produção
        $events = Event::where('production_id', $production->id)->get();
        return view('crud.productions.show', compact('production', 'events'));
    }

    public function edit(Production $production)
    {
        return view('crud.productions.update', compact('production'));
    }

    public function update(Request $request, Production $production)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $imagePath = $production->image;
        $directoryPath = public_path('productions');

        if (!File::exists($directoryPath)) {
            File::makeDirectory($directoryPath, 0755, true);
        }

        if ($request->hasFile('image')) {
            $imgprod = $request->file('image');

            // Check if there's a file with the same name as the uploaded file
            if (File::exists($directoryPath . '/' . $imgprod->getClientOriginalName())) {
                // Generate a new unique file name by adding a number to the end of the original file name
                $count = 1;
                $newFileName = pathinfo($imgprod->getClientOriginalName(), PATHINFO_FILENAME) . '_' . $count . '.' . $imgprod->getClientOriginalExtension();

                while (File::exists($directoryPath . '/' . $newFileName)) {
                    $count++;
                    $newFileName = pathinfo($imgprod->getClientOriginalName(), PATHINFO_FILENAME) . '_' . $count . '.' . $imgprod->getClientOriginalExtension();
                }

                // Rename the existing file with the new unique name
                File::move($directoryPath . '/' . $imgprod->getClientOriginalName(), $directoryPath . '/' . $newFileName);

                $imagePath = 'productions/' . $newFileName;
            } else {
                // If the file does not exist, simply move the uploaded file to the logos directory
                $imgprod->move($directoryPath, $imgprod->getClientOriginalName());
                $imagePath = 'productions/' . $imgprod->getClientOriginalName();
            }
        }

        $production->update([
            'name' => $request->name,
            'image' => $imagePath,
            'location' => $request->location,
        ]);

        return redirect()->route('productions.show', $production->id)->with('success', 'Produção atualizada com sucesso!');
    }

    public function destroy(Production $production)
    {
        $production->delete();
        return redirect()->route('productions.index')->with('success', 'Produção excluída com sucesso!');
    }
}
