

<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="col-12">
        <div class="bg-secondary rounded h-100 p-4">
            <h6 class="mb-4">Lista de produções</h6>
            <div class="mb-3">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createproductionModal">Adicionar </button>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col"></th>
                            <!-- Adicione mais colunas para os outros atributos, se necessário -->
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $productions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $production): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="rounded">
                                    <a href="<?php echo e(route('production.show', $production->id)); ?>">       <img src="<?php echo e(asset($production->image_url)); ?>" alt="Imagem do Produtor" class="img-thumbnail rounded" style="width: 30%; height: auto;">
                                    </a>
                                    <p class="text-info ">
                                        <?php echo e($production->name); ?> </p>  <p class="text-info">
                                            <?php echo e($production->location); ?> </p></td>
                                <!-- Adicione mais colunas para os outros atributos, se necessário -->
                                <td>
                                    
                                    <button type="button" class="btn btn-danger" onclick="openDeleteConfirmationModal(<?php echo e($production->id); ?>)">Excluir</button>
                    
</td>
                            </tr><hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal fade " id="createproductionModal" tabindex="-1" aria-labelledby="createproductionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl ">
        <div class="modal-content bg-secondary ">
            <div class="modal-header">
                <h5 class="modal-title" id="createproductionModalLabel">Cadastro de Produtor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
                        <div class="col-md-10">
                          
                                
                                <h6 class="mb-4">Cadastro de Produtor</h6>
                                <form method="POST" action="<?php echo e(route('productions.store')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                
                                    <div class="row mb-3">
                                        <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nome')); ?></label>
                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                
                                    <div class="row mb-3">
                                        <label for="location" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Localização')); ?></label>
                                        <div class="col-md-6">
                                            <input id="location" type="text" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="location" value="<?php echo e(old('location')); ?>" required autocomplete="location">
                                            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                
                                    <div class="row mb-3">
                                        <label for="image" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Imagem')); ?></label>
                                        <div class="col-md-6">
                                            <input id="image" type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image" required>
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                
                                    <!-- Add more fields as necessary -->
                                
                                    <div class="row mb-3">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Cadastrar Produtor')); ?>

                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <h4>Descubra as Inúmeras Vantagens de Cadastrar sua Produção na GateGun!</h4>
                                <p>A GateGun é a plataforma definitiva para produtores de eventos que buscam alcançar o ápice em organização, sucesso e experiência do público. Com um conjunto completo de funcionalidades gerenciais de eventos, ingressos, participantes e artistas, cadastrar sua produção na GateGun proporciona uma série de vantagens que farão toda a diferença no resultado do seu evento.</p>
                                
                                <h6>1. Gestão de Eventos Simplificada:</h6>
                                <p>A GateGun oferece uma experiência única em gestão de eventos. Desde a criação até a conclusão, a plataforma torna o processo simples e intuitivo. Com uma interface amigável, você pode facilmente configurar e atualizar informações essenciais sobre o evento, como data, local, programação e muito mais.</p>
                                
                                <h6>2. Controle Total dos Ingressos:</h6>
                                <p>Garantir uma venda de ingressos bem-sucedida é fundamental para qualquer evento. A GateGun permite que você tenha controle total sobre a venda de ingressos, incluindo a criação de diferentes tipos de bilhetes, promoções e descontos. Além disso, você pode acompanhar em tempo real as vendas e disponibilidade de ingressos.</p>
                                
                                <h6>3. Gerenciamento de Participantes Descomplicado:</h6>
                                <p>Gerenciar a lista de participantes nunca foi tão fácil. Com a GateGun, você pode acompanhar as inscrições e obter informações detalhadas sobre cada participante. Além disso, a plataforma facilita o check-in no dia do evento, garantindo uma entrada tranquila para todos os participantes.</p>
                                
                                <h6>4. Integração Perfeita com Artistas e Atrações:</h6>
                                <p>Na GateGun, você pode facilmente convidar e gerenciar artistas e atrações que estarão presentes no seu evento. Compartilhe informações importantes, contratos e cronogramas, garantindo que todos estejam alinhados para proporcionar um show incrível ao público.</p>
                                
                                <h6>5. Divulgação Abrangente e Eficaz:</h6>
                                <p>A GateGun valoriza a visibilidade do seu evento. Além de criar uma página personalizada com informações completas, você pode compartilhar o evento em diferentes plataformas, alcançando um público mais amplo. Isso contribui para o sucesso do evento e cria uma experiência única para os participantes.</p>
                                
                                <h6>6. Comunicação Direta com o Público:</h6>
                                <p>A plataforma permite que você interaja diretamente com o público, respondendo a perguntas, fornecendo atualizações e mantendo todos informados sobre o evento. Essa comunicação direta cria um vínculo com o público e aumenta a confiança e satisfação dos participantes.</p>
                                
                                <h6>7. Segurança e Credibilidade:</h6>
                                <p>Ao cadastrar sua produção na GateGun, você garante uma experiência segura e confiável para os participantes. A plataforma valoriza a segurança das transações e é reconhecida no mercado por sua credibilidade.</p>
                                
                                <h6>8. Acesso a Dados Analíticos Preciosos:</h6>
                                <p>A GateGun fornece análises detalhadas sobre o desempenho do seu evento. Com esses insights, você pode avaliar o sucesso da produção, identificar pontos fortes e oportunidades de melhoria para futuros eventos.</p>
                                
                                <p>Em suma, cadastrar sua produção na GateGun é a escolha certa para aprimorar sua gestão de eventos, ingressos, participantes e artistas. Com uma abordagem abrangente e funcionalidades poderosas, a plataforma proporciona um evento inesquecível para o público e o sucesso que você almeja como produtor. Não espere mais, junte-se à GateGun e eleve suas produções a um patamar extraordinário!</p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Modal de confirmação de exclusão -->
<div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-secondary ">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirmar Exclusão</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <p>Tem certeza que deseja excluir este produtor?</p>
                <p>Essa ação é irreversível e excluirá permanentemente todos os dados associados a este produtor.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form id="deleteForm" method="POST" action="">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Excluir</button>
                </form>
            </div>
        </div>
    </div>
    
</div>


<!-- Script para abrir o modal de confirmação de exclusão -->
<script>
    function openDeleteConfirmationModal(productionId) {
        const deleteForm = document.getElementById('deleteForm');
        deleteForm.action = "<?php echo e(route('productions.destroy', '')); ?>" + "/" + productionId;
        $('#deleteConfirmationModal').modal('show');
    }
    function openAddEventModal(productionId) {
        const deleteForm = document.getElementById('deleteForm');
        deleteForm.action = "<?php echo e(route('events.store', '')); ?>" + "/" + productionId;
        $('#addEventModal').modal('show');
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gategun\backend\resources\views/crud/production/index.blade.php ENDPATH**/ ?>