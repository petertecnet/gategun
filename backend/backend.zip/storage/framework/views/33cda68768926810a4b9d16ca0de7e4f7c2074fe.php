

<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="col-12">
        <div class="bg-secondary rounded h-100 p-4">
            <h6 class="mb-4">Lista de Produtores</h6>
            <div class="mb-3">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createProducerModal">Cadastrar Novo Produtor</button>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col"></th>
                            <!-- Adicione mais colunas para os outros atributos, se necessário -->
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $producers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="rounded">
                                    <a href="<?php echo e(route('producer.show', $producer->id)); ?>">       <img src="<?php echo e(asset($producer->image_url)); ?>" alt="Imagem do Produtor" class="img-thumbnail rounded" style="width: 30%; height: auto;">
                                    </a>
                                    <p class="text-info ">
                                        <?php echo e($producer->name); ?> </p>  <p class="text-info">
                                            <?php echo e($producer->location); ?> </p></td>
                                <!-- Adicione mais colunas para os outros atributos, se necessário -->
                                <td>
                                    
                                    <button type="button" class="btn btn-danger" onclick="openDeleteConfirmationModal(<?php echo e($producer->id); ?>)">Excluir</button>
                    
</td>
                            </tr><hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal fade " id="createProducerModal" tabindex="-1" aria-labelledby="createProducerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl ">
        <div class="modal-content bg-secondary ">
            <div class="modal-header">
                <h5 class="modal-title" id="createProducerModalLabel">Cadastro de Produtor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
                        <div class="col-md-10">
                          
                                
                                <h2 class="mb-4">Cadastro de Produtor</h2>
                                <form method="POST" action="<?php echo e(route('producer.store')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                
                                    <div class="row mb-3">
                                        <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nome')); ?></label>
                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                
                                    <div class="row mb-3">
                                        <label for="location" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Localização')); ?></label>
                                        <div class="col-md-6">
                                            <input id="location" type="text" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="location" value="<?php echo e(old('location')); ?>" required autocomplete="location">
                                            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                
                                    <div class="row mb-3">
                                        <label for="image" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Imagem')); ?></label>
                                        <div class="col-md-6">
                                            <input id="image" type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image" required>
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                
                                    <!-- Add more fields as necessary -->
                                
                                    <div class="row mb-3">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Cadastrar Produtor')); ?>

                                            </button>
                                        </div>
                                    </div>
                                </form>
                                
                                <p class="mb-4">Seja bem-vindo ao cadastro de produtor da Gategun! Aqui você pode registrar todas as informações relevantes sobre os produtores que trabalham conosco.</p>
                                <p class="mb-4">Vantagens de cadastrar o produtor na Gategun:</p>
                                <ul class="mb-4">
                                    <li>Gerencie e acompanhe informações importantes de cada produtor.</li>
                                    <li>Centralize dados sobre a localização dos produtores e suas atividades.</li>
                                    <li>Visualize de forma organizada as imagens e detalhes dos produtores cadastrados.</li>
                                    <li>Obtenha acesso rápido às informações quando necessário.</li>
                                    <!-- Adicione mais vantagens relevantes se desejar -->
                                </ul>
                                <p class="mb-4">Preencha o formulário abaixo para cadastrar um novo produtor na plataforma. Certifique-se de fornecer informações precisas e atualizadas.</p>
                
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Modal de confirmação de exclusão -->
<div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-secondary ">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirmar Exclusão</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <p>Tem certeza que deseja excluir este produtor?</p>
                <p>Essa ação é irreversível e excluirá permanentemente todos os dados associados a este produtor.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form id="deleteForm" method="POST" action="">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Excluir</button>
                </form>
            </div>
        </div>
    </div>
    
</div>


<!-- Script para abrir o modal de confirmação de exclusão -->
<script>
    function openDeleteConfirmationModal(producerId) {
        const deleteForm = document.getElementById('deleteForm');
        deleteForm.action = "<?php echo e(route('producer.destroy', '')); ?>" + "/" + producerId;
        $('#deleteConfirmationModal').modal('show');
    }
    function openAddEventModal(producerId) {
        const deleteForm = document.getElementById('deleteForm');
        deleteForm.action = "<?php echo e(route('events.store', '')); ?>" + "/" + producerId;
        $('#addEventModal').modal('show');
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gategun\backend\resources\views/crud/producer/index.blade.php ENDPATH**/ ?>