

<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <h1>New Event Producer Registration</h1>
    <form action="<?php echo e(route('event_producers.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="tel" class="form-control" id="phone" name="phone" required>
        </div>
        <!-- Add more fields as needed for event producer registration -->

        <button type="submit" class="btn btn-primary">Register</button>
    </form>
</div>

<!-- Owl Carousel CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<!-- Owl Carousel JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add your API request and carousel logic here as needed
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gategun\backend\resources\views/crud/producer/new.blade.php ENDPATH**/ ?>