

<?php $__env->startSection('content'); ?>

            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    
                    <div class="col-md-12">
                        <div class="h-100 bg-secondary rounded p-4 d-flex flex-column align-items-center justify-content-center">
                            <img src="<?php echo e(asset($producer->image_url)); ?>" alt="Imagem do Produtor" class="img-thumbnail circle" style="width: 20%; height: auto;">
                            <h2 class="text-center mt-2"><?php echo e($producer->name); ?></h2>
                            <p class="text-center"><?php echo e($ownerName); ?></p>
                        </div>
                    </div>
                    
                
                    
    <hr>

    <!-- Exibindo a lista de eventos como cards -->
    <h2>Eventos  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEventModal">
       Novo
    </button></h2>

              
        <?php if(count($events) > 0): ?>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12 col-md-6 col-xl-4">
                <div class="h-100 bg-secondary rounded p-4">
                    <a href="<?php echo e(route('events.show', $event->id)); ?>">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <h6 class="mb-0"><?php echo e($event->name); ?></h6>
                        </div>
                        <div class="d-flex align-items-center border-bottom py-3">
                            <img class="rounded-circle flex-shrink-0" src="<?php echo e(asset('storage/' . $event->image)); ?>" alt="" style="width: 40px; height: 40px;">
                            <div class="w-100 ms-3">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-0"><?php echo e($event->date->format('d/m/Y')); ?></h6>
                                    <small>
                                        <p class="card-text">às <?php echo e($event->time); ?></p>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>Nenhum evento cadastrado para este produtor.</p>
    <?php endif; ?>
    
            </div>
        </div>

        <div class="modal fade " id="addEventModal" tabindex="-1" aria-labelledby="addEventModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl ">
                <div class="modal-content bg-secondary text-info">
                    <div class="modal-header">
                        <h5 class="modal-title text-info" id="addEventModalLabel">Cadastro de Evento</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container-fluid">
                            <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
                                <div class="col-md-10 ">
                                  
                                    <h8 class="text-center"> Mais visibilidade, alcance de público amplo, gestão eficiente, organização e facilidade na divulgação. Funcionalidades: Campos obrigatórios, imagem, registro, edição e exclusão.</h8>
                                     
                                        <h2 class="mb-4 text-info">     <?php echo e($producer->name); ?> - <?php echo e($producer->id); ?></h2>
                                        <form method="POST" action="<?php echo e(route('events.store')); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" id="producer_id" name="producer_id" value="<?php echo e($producer->id); ?>">
                                            <input type="hidden" id="producer_name" name="producer_name" value="<?php echo e($producer->name); ?>">
                                       
                                            <div class="row mb-3">
                                                <label for="image" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Imagem do Evento')); ?></label>
                                                <div class="col-md-6">
                                                    <input id="image" type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image" required>
                                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nome do Evento')); ?></label>
                                                <div class="col-md-6">
                                                    <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                    
                                            <div class="row mb-3">
                                                <label for="description" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Descrição')); ?></label>
                                                <div class="col-md-6">
                                                    <textarea id="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" rows="4" required><?php echo e(old('description')); ?></textarea>
                                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                    
                                            <div class="row mb-3">
                                                <label for="date" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Data do Evento')); ?></label>
                                                <div class="col-md-6">
                                                    <input id="date" type="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="date" value="<?php echo e(old('date')); ?>" required>
                                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                    
                                            <div class="row mb-3">
                                                <label for="time" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Horário')); ?></label>
                                                <div class="col-md-6">
                                                    <input id="time" type="time" class="form-control <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="time" value="<?php echo e(old('time')); ?>" required>
                                                    <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                    
                                            <div class="row mb-3">
                                                <label for="location" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Local')); ?></label>
                                                <div class="col-md-6">
                                                    <input id="location" type="text" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="location" value="<?php echo e(old('location')); ?>" required>
                                                    <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                    
                                            <div class="row mb-3">
                                                <label for="price" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Preço')); ?></label>
                                                <div class="col-md-6">
                                                    <input id="price" type="number" step="0.01" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price" value="<?php echo e(old('price')); ?>" required>
                                                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                    
                                    
                                            <div class="row mb-3">
                                                <div class="col-md-6 offset-md-4">
                                                    <button type="submit" class="btn btn-primary">
                                                        <?php echo e(__('Cadastrar Evento')); ?>

                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                  
                                      
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  
<script>
    function openDeleteConfirmationModal(eventId) {
        const deleteForm = document.getElementById('deleteForm');
        deleteForm.action = "<?php echo e(route('events.destroy', '')); ?>" + "/" + eventId;
        $('#deleteConfirmationModal').modal('show');
    }
    function openAddEventModal(producerId) {
        const deleteForm = document.getElementById('deleteForm');
        deleteForm.action = "<?php echo e(route('events.store', '')); ?>" + "/" + producerId;
        $('#addEventModal').modal('show');
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gategun\backend\resources\views/crud/producer/show.blade.php ENDPATH**/ ?>