

<?php $__env->startSection('content'); ?>

<div class="container-fluid pt-4 px-4">
    <div class="row g-4">  
        <div class="col-md-12">
            <div class="bg-secondary rounded p-4 d-flex flex-column align-items-center justify-content">
                <h4>Meus ingressos:</h4>
               
            </div>
        </div>
    </div>
</div>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">  
        <div class="col-md-12">
            <div class="bg-info  p-4">
             <div id="ticketList">
             </div>
               
            </div>
        </div>
    </div>
</div>
<script>
    // Função para buscar os tickets de ingresso via API
    async function getIngressoTickets() {
        try {
            const response = await fetch('/items');
            const data = await response.json();
            const ticketList = document.getElementById('ticketList');
            ticketList.innerHTML = '';

            // Itera pelos tickets de ingresso e adiciona na lista
            data.forEach(ticket => {
    const ticketItem = document.createElement('div');
    ticketItem.classList.add('col-md-12'); // Defina o tamanho da coluna conforme sua preferência

    ticketItem.innerHTML = `
    <div class="col-md-12">
        <div class="card bg-secondary rounded d-flex flex-column">
           
        <div class="card bg-dark rounded p-4 d-flex flex-column ">
            <div class="card-body">
                <h5 class="card-title">${ticket.name}</h5>
                <p class="card-text">
                    <strong><a href="/events/${ticket.eventid}">Evento</a></strong><br>
                    <strong>Descrição:</strong> ${ticket.description}<br>
                    <strong>Status de Utilização:</strong> ${ticket.is_used ? 'Utilizado' : 'Não utilizado'}
                </p>
            </div>
        </div>
        </div>
        </div>
    `;

    ticketList.appendChild(ticketItem);
});

        } catch (error) {
            console.error('Erro ao buscar tickets de ingresso:', error);
        }
    }

    // Chama a função para buscar os tickets de ingresso assim que a página for carregada
    window.addEventListener('load', getIngressoTickets);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gategun\backend\resources\views/crud/tickets/index.blade.php ENDPATH**/ ?>