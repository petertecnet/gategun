
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row ">
        <div class="col-md-12">
            <div class="card bg-secondary ">
                <div class="card-header "> 
                    <div class="row ">
                    <div class="col-md  p-1">
                        <a href="<?php echo e(route('productions.show', $event->production_id)); ?>"><button type="button"
                                class="btn btn-success tet-white aling-right">
                                <?php echo e($event->production_name); ?></button></a></div>
              
                                <div class="col-md  p-1 ">  <button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addEventModal">
                                    Cadastrar Ingresso
                                </button></div>
                             
                    <div class="col-md  p-1 ">
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#eventCancel">Cancelar evento</button>
  </div>
</div>
</div>
                <div class="card-body">
                   

                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row ">
        <div class="col-md-12">
            <div class="card bg-secondary">
                <div class="card-header">     <a href="<?php echo e(route('events.show', $event->id)); ?>"><button type="button"
                                class="btn btn-info tet-white aling-right">
                                <?php echo e($event->name); ?> </button></a></div>
                <div class="card-body">
                    
                    <img src="<?php echo e(asset($event->image)); ?>" alt="" class="card-img-top img-event-sm-gategun " >
              
                    <form action="<?php echo e(route('events.update', $event->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        
                        <?php echo $__env->make('crud.events.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row ">
        <div class="col-md-12">
            <div class="card bg-secondary">
                <div class="card-header">Ingressos </div>
                <div class="card-body">
                
                    <?php if($tickets && count($tickets) > 0): ?>
                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3  p-6 ">
                            <div class="bg-gategun rounded p-6 h-100">
                                    <div class="d-flex align-items-center justify-content-center mb-2">
                                        <h6 class="mb-0 text-gategunwhite"><?php echo e($ticket->name); ?></h6>
                                    </div>
                                    <div class="d-flex align-items-center border-bottom py-3 ">
                                        <div class="w-100 ms-3">
                                            <div class="d-flex w-100 justify-content-center">
                                                <h6 class="text-gategunwhite"><?php echo e('R$ ' . number_format($ticket->price, 2, ',', '.')); ?></h6>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-md-12">
                            <p>Nenhum ingresso cadastrado para este produtor.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Confirmação -->
<div class="modal fade" id="eventCancel" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content bg-secondary">
            <div class="modal-header">
                <h5 class="modal-title text-info" id="deleteModalLabel"> <?php echo e($event->name); ?> </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Deseja realmente cancelar  o evento <?php echo e($event->name); ?>?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" id="deleteProductionButton">Cancelar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Modal para cadastro de ingresso -->
<div class="modal fade" id="addEventModal" tabindex="-1" role="dialog" aria-labelledby="addEventModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content bg-secondary">
            <div class="modal-header">
                <h5 class="modal-title" id="addEventModalLabel">Cadastrar Ingresso</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Formulário para cadastrar o ingresso -->
                <form action="<?php echo e(route('tickets.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="event_id" id="event_id" value="<?php echo e($event->id); ?>">
                    <input type="hidden" name="production_name" id="production_name" value="<?php echo e($event->name); ?>">
                     <div class="row mb-3">
                        <label for="ticket_type" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Tipo de Ingresso')); ?></label>
                        <div class="col-md-6">
                            <select id="ticket_type" class="form-control <?php $__errorArgs = ['ticket_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ticket_type" required>
                                <option value="" disabled selected>Selecione o tipo de ingresso</option>
                                <option value="VIP">VIP</option>
                                <option value="Normal">Normal</option>
                                <option value="Estudante">Estudante</option>
                                <!-- Adicione mais opções de acordo com a necessidade -->
                            </select>
                            <?php $__errorArgs = ['ticket_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                     <div class="row mb-3">
                        <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nome do Ingresso')); ?></label>
                        <div class="col-md-6">
                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="quantity" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Quantidade de Ingressos Disponíveis')); ?></label>
                        <div class="col-md-6">
                            <input id="quantity" type="number" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="quantity" value="<?php echo e(old('quantity')); ?>" required>
                            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="time" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Horário limite de entrada')); ?></label>
                        <div class="col-md-6">
                            <input id="time" type="time" class="form-control <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="time" value="<?php echo e(old('time')); ?>" required>
                            <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                
                    <div class="row mb-3">
                        <label for="price" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Preço')); ?></label>
                        <div class="col-md-6">
                            <input id="price" type="number" step="0.01" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price" value="<?php echo e(old('price')); ?>" required>
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                
                
                    <div class="row mb-3">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Cadastrar Ingresso')); ?>

                            </button>
                        </div>
                    </div>
                </form>
                
            </div>
        </div>
        
    </div>



<script>
    function decreaseQuantity() {
        const inputElement = document.getElementById('quantityInput');
        let currentValue = parseInt(inputElement.value);

        if (currentValue > 0) {
            currentValue--;
            inputElement.value = currentValue;
        }
    }

    function increaseQuantity() {
        const inputElement = document.getElementById('quantityInput');
        let currentValue = parseInt(inputElement.value);

        currentValue++;
        inputElement.value = currentValue;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gategun\backend\resources\views/crud/events/update.blade.php ENDPATH**/ ?>