<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
   
    <div class="row g-4">
         <div class="col">
            
        <div class="h-100 bg-secondary rounded p-4">
            <h3>Descubra Eventos Incríveis</h3>
            <p>Com a Gategun, você tem acesso a uma ampla variedade de eventos incríveis para participar. Navegue pela lista de eventos em diversas categorias, desde shows e festivais até conferências e workshops. Explore novas experiências e encontre os eventos que mais combinam com seus interesses e paixões.</p>
 </div>
</div>
</div>
</div>


<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        
        <?php if(count($events) > 0): ?>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card border-0 ">
                    <a href="<?php echo e(route('events.show', $event->id)); ?>" >  <img src="<?php echo e(asset($event->image)); ?>" alt="<?php echo e($event->name); ?>" class="card-img-top">
                    </a>
                    <div class="card-body bg-secondary">
                        <h5 class="card-title text-gategun"><?php echo e($event->name); ?></h5>
                        <p class="card-text text-primary ">
                          
                            <?php echo e($event->date->format('d/m/Y')); ?> ás <?php echo e($event->time); ?> 
                            <p>R$<?php echo e($event->price); ?></p> 
                             
                        </p>
                    </div>
                    <div class=" card-footer border-0 text-center">
                     
                        <a href="<?php echo e(route('productions.show', $event->production_id)); ?>" class="text-dark "> <?php echo e($event->production_name); ?></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="col-md-12">
            <p class="text-center text-gategun">Nenhum evento cadastrado para este produtor.</p>
        </div>
    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gategun\backend\resources\views/home.blade.php ENDPATH**/ ?>