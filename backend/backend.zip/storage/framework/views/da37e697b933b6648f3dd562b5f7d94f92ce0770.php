
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row ">
        <div class="col-md-12">
            <div class="card bg-secondary">
                <div class="card-header"> 
                    <a href="<?php echo e(route('productions.show', $production->id)); ?>"><button type="button"
                            class="btn btn-success tet-white aling-right">
                            <?php echo e($production->name); ?></button></a>
                            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal">Excluir produção</button>
      
                </div>
                <div class="card-body">
                   

                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row ">
        <div class="col-md-12">
            <div class="card bg-secondary">
                <div class="card-header"><?php echo e($production->name); ?> </div>
                <div class="card-body">
                    <img src="<?php echo e(asset($production->image)); ?>" alt="" class="card-img-top img-event-sm-gategun " >
              
                    <form action="<?php echo e(route('productions.update', $production->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        
                        <?php echo $__env->make('crud.productions.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
        
    </div>
</div>

<div class="container">
<div class="row ">
    <div class="col-md-12">
        <div class="card bg-secondary h-100 bg-secondary rounded p-4">
            <div class="card-header">
            <h3 class="mb-3">Eventos de <?php echo e($production->name); ?> </h3>
            </div>
            <div class="text-center mb-3">
            <button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addEventModal">Adicionar Novo Evento</button>
            </div>
            <?php if($production->events && count($production->events) > 0): ?>
    
                <ul class="list-group">
    
                    <?php $__currentLoopData = $production->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                        <li class="list-group-item d-flex justify-content-between align-items-center">
    
                            <img src="<?php echo e(asset('storage/' . $event->image)); ?>" alt="" class="card-img-top img-event-sm-gategun" >
                            <?php echo e($event->name); ?>

                            <?php echo e($event->name); ?>

     
                            <div>
                
                                <a href="<?php echo e(route('events.show', $event->id)); ?>" class="btn btn-primary btn-sm me-2">Detalhes</a>
    
                                <?php if(Auth::user()->id == $production->user_id): ?>
                                <a href="<?php echo e(route('events.edit', $event->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
    <?php endif; ?>
                            </div>
    
                        </li>
    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                </ul>
    
            <?php else: ?>
    
                <p>Nenhum evento encontrado.</p>
    
            <?php endif; ?>
    
        </div>
    
    </div>
</div>
</div>

<!-- Modal Adicionar Novo Evento -->
<div class="modal fade " id="addEventModal" tabindex="-1" aria-labelledby="addEventModalLabel" aria-hidden="true">
    <div class="modal-dialog bg-secondary modal-lg">
        <div class="modal-content bg-secondary">
            <div class="modal-header">
                <h5 class="modal-title" id="addEventModalLabel">Adicionar Novo Evento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('events.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">Nome do Evento</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Descrição do Evento</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="date" class="form-label">Data do Evento</label>
                        <input type="date" class="form-control" id="date" name="date" required>
                    </div>
                    <div class="mb-3">
                        <label for="time" class="form-label">Hora do Evento</label>
                        <input type="time" class="form-control" id="time" name="time" required>
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">Preço do Evento</label>
                        <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Imagem do Evento</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                    </div>
                    <input type="hidden" name="location" value="<?php echo e($production->location); ?>">                  
                    <input type="hidden" name="production_id" value="<?php echo e($production->id); ?>">
                    <input type="hidden" name="production_name" value="<?php echo e($production->name); ?>">
                    <button type="submit" class="btn btn-primary">Salvar Evento</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Confirmação -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content bg-secondary">
            <div class="modal-header">
                <h5 class="modal-title text-info" id="deleteModalLabel"> <?php echo e($production->name); ?> </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Deseja realmente excluir a <?php echo e($production->name); ?> produções?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form action="<?php echo e(route('productions.destroy', $production->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" id="deleteProductionButton">Cancelar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gategun\backend\resources\views/crud/productions/update.blade.php ENDPATH**/ ?>