

<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route('tickets.show', $event->id)); ?>" class="btn btn-primary btn-fixed-gategun">Ingressos R$<?php echo e($event->price); ?></a>
<div class="container-fluid pt-4 px-4 ">
    <div class="row g-4">  
        
        <div class="col-md-8">
            <div class=" bg-secondary rounded p-4 d-flex flex-column align-items-center justify-content">
                <img src="<?php echo e(asset($event->image)); ?>" alt="" class="card-img-top img-event-gategun" >
                
            </div>
        </div>
              
        <div class="col-md-4">
            <div class="h-10 bg-secondary rounded p-4 d-flex flex-column align-items-center justify-content-">
                <p class="text-info">    <?php echo e($event->name); ?> </p>
                <a href="https://www.google.com/maps?q=<?php echo e($event->location); ?>" target="_blank" class="btn btn-primary m-2">
                    <i class="fa-solid fa-location"></i> 
                    Localização
                </a>
                <p class="text-primary">       <a href="<?php echo e(route('productions.show', $event->production_id)); ?>" class="text-primary "> <?php echo e($event->production_name); ?></a>
                </p>
            <hr class="bg-primary">
            <p> <?php echo e($event->date->formatLocalized('%A')); ?></p>
            

                <p>   <?php echo e($event->date->format('d/m/Y')); ?> ás <?php echo e($event->time); ?> </p> 
                <p>R$<?php echo e($event->price); ?></p> 
                
               
                                
            </div>
        </div>
        <hr>
        <div class="col-md-12">
            <div class="accordion-item bg-transparent  bg-info">
                <h2 class="accordion-header  align-items-center justify-content" id="headingTwo">
                    <button class="accordion-button collapsed " type="button"
                        data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                        aria-expanded="false" aria-controls="collapseTwo">
                       Descrição
                    </button>
                </h2>
                <div id="collapseTwo" class="accordion-collapse collapse"
                    aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        <?php echo e($event->description); ?> 
                    </div>
                </div>
            </div>
        </div>
    <div class="col-md-12 ">
        <div class="bg-secondary rounded h-200 p-4">
            <iframe
            width="100%"
            height="100%"
            frameborder="0"
            style="border: 0"
            src="https://www.google.com.br/maps?q=72225-509,%20Brasil&output=embed"
            allowfullscreen
        ></iframe>
        </div>
    </div>
    </div>
</div>

<!-- Modal para cadastro de ingresso -->
<div class="modal fade" id="addEventModal" tabindex="-1" role="dialog" aria-labelledby="addEventModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content bg-secondary">
            <div class="modal-header">
                <h5 class="modal-title" id="addEventModalLabel">Cadastrar Ingresso</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Formulário para cadastrar o ingresso -->
                <form action="<?php echo e(route('tickets.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="event_id" id="event_id" value="<?php echo e($event->id); ?>">
                    <div class="row mb-3">
                        <label for="ticket_type" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Tipo de Ingresso')); ?></label>
                        <div class="col-md-6">
                            <select id="ticket_type" class="form-control <?php $__errorArgs = ['ticket_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ticket_type" required>
                                <option value="" disabled selected>Selecione o tipo de ingresso</option>
                                <option value="VIP">VIP</option>
                                <option value="Normal">Normal</option>
                                <option value="Estudante">Estudante</option>
                                <!-- Adicione mais opções de acordo com a necessidade -->
                            </select>
                            <?php $__errorArgs = ['ticket_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                     <div class="row mb-3">
                        <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nome do Ingresso')); ?></label>
                        <div class="col-md-6">
                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="quantity" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Quantidade de Ingressos Disponíveis')); ?></label>
                        <div class="col-md-6">
                            <input id="quantity" type="number" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="quantity" value="<?php echo e(old('quantity')); ?>" required>
                            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="time" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Horário limite de entrada')); ?></label>
                        <div class="col-md-6">
                            <input id="time" type="time" class="form-control <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="time" value="<?php echo e(old('time')); ?>" required>
                            <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                
                    <div class="row mb-3">
                        <label for="price" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Preço')); ?></label>
                        <div class="col-md-6">
                            <input id="price" type="number" step="0.01" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price" value="<?php echo e(old('price')); ?>" required>
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                
                
                    <div class="row mb-3">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Cadastrar Ingresso')); ?>

                            </button>
                        </div>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
</div>

<script>
    function decreaseQuantity() {
        const inputElement = document.getElementById('quantityInput');
        let currentValue = parseInt(inputElement.value);

        if (currentValue > 0) {
            currentValue--;
            inputElement.value = currentValue;
        }
    }

    function increaseQuantity() {
        const inputElement = document.getElementById('quantityInput');
        let currentValue = parseInt(inputElement.value);

        currentValue++;
        inputElement.value = currentValue;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gategun\backend\resources\views/crud/events/show.blade.php ENDPATH**/ ?>