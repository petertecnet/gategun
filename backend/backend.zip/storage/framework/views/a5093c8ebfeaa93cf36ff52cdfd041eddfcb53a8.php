

<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <?php if($cart && count($cart->items) > 0): ?>
        <div class="col-md-12">
            <div class="h-100 bg-secondary rounded p-4 d-flex flex-column align-items-center justify-content-center">
                <h4>Total: R$ <?php echo e(number_format($cart->getTotalPrice(), 2, ',', '.')); ?></h4>
                <a href="<?php echo e(route('cart.generateQRCode')); ?>" class="btn btn-primary">Gerar QR CODE PIX</a>
            </div>
        </div>
        <?php endif; ?>
        <hr>
        <div class="container">
            <div class="col-md-12">
                <div class="h-100 bg-secondary rounded flex-column align-items-center justify-content-center p-4 ">
                    <?php if($cart && count($cart->items) > 0): ?>
                    <div class="row">
                        <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="item-card">
                                    <div class="card-header">
                                        <p><?php echo e($item['name']); ?></p>
                                    </div>
                                    <div class="card-body">
                                        <p><strong>Quantidade:</strong> <?php echo e($item['quantity']); ?></p>
                                        <p><strong>Valor Unitário:</strong> R$ <?php echo e(number_format($item['price'], 2, ',', '.')); ?></p>
                                        <p><strong>Valor Total:</strong> R$ <?php echo e(number_format($item['quantity'] * $item['price'], 2, ',', '.')); ?></p>
                                    </div>
                                    <div class="card-footer">
                                        <form action="<?php echo e(route('cart.update', $item['id'])); ?>" method="POST" class="d-flex align-items-right justify-content-right">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="quantity" value="0" class="form-control" style="width: 20px;">
                                            <button type="submit" class="btn btn-sm btn-primary ms-2 align-items-right justify-content-right">
                                                <i class="fa fa-trash"></i> 
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
            <div class="col-md-12">
                <div class="h-100 bg-secondary rounded p-4 d-flex flex-column align-items-center justify-content-center">
                    <p>Carrinho vazio.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gategun\backend\resources\views/crud/cart/index.blade.php ENDPATH**/ ?>